<div id="icon-options-general" class="icon32"></div>
<h2 class="nav-tab-wrapper">
	<a href="?page=pp-config" class="nav-tab <?php echo isset( $_GET['page'] ) && $_GET['page'] == 'pp-config' ? 'nav-tab-active' : ''; ?>">Settings</a>
	<a href="?page=pp-login" class="nav-tab <?php echo isset( $_GET['page'] ) && $_GET['page'] == 'pp-login' ? 'nav-tab-active' : ''; ?>">Login</a>
	<a href="?page=pp-registration" class="nav-tab <?php echo isset( $_GET['page'] ) && $_GET['page'] == 'pp-registration' ? 'nav-tab-active' : ''; ?>">Registration</a>
	<a href="?page=pp-password-reset" class="nav-tab <?php echo isset( $_GET['page'] ) && $_GET['page'] == 'pp-password-reset' ? 'nav-tab-active' : ''; ?>">Password Reset</a>
	<a href="https://profilepress.net/pricing/" class="nav-tab" target="_blank">Go Premium</a>
	<a href="https://profilepress.net/themes/" class="nav-tab" target="_blank">Themes</a>
	<a href="https://profilepress.net/extensions/" class="nav-tab" target="_blank">Extensions</a>
</h2>